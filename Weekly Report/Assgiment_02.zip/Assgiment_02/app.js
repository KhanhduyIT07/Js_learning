// const $ = document.querySelector.bind(document);

const loan = document.querySelector('#loan');
const term = document.querySelector('#term');
const rate = document.querySelector('#rate');
const date = document.querySelector('#date');
const btnCalc = document.querySelector('.btn-calc');
const tBody = document.querySelector('.table-body');

// ~ Format number
function formatNumber(num) {
  const numFormat = num.toFixed(0).split('');
  const numFormatLength = numFormat.length;

  let i = 0;
  for (i; i < numFormatLength; i += 3)
    numFormat.splice(numFormatLength - i, 0, ',');

  return numFormat.join('').slice(0, -1);
}

// ~ Handle Loan
function handleLoan() {
  const loanValue = loan.value;
  const termValue = term.value;
  const rateValue = rate.value;
  const dateValue = new Date(date.value);

  let sumPrincipal = 0;
  let sumInterest = 0;
  let loanCurr = +loanValue;

  let html = `
    <tr class="gray">
      <td>${dateValue.toLocaleDateString("en-GB")}</td>
      <td>0</td>
      <td>${formatNumber(+loanCurr)}</td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  `;

  let i = 1;
  for (i; i <= termValue; i++) {
    const principal = loanValue / termValue;
    const interest = (loanCurr * (rateValue / 100)) / 12;
    const sum = principal + interest;

    dateValue.setMonth(dateValue.getMonth() + 1);

    sumPrincipal += principal;
    sumInterest += interest;
    loanCurr -= principal;

    html += `
      <tr class=${i % 2 == 0 ? 'gray' : 'gray-light'}>
        <td>${dateValue.toLocaleDateString("en-GB")}</td>
        <td>${i}</td>
        <td>${formatNumber(loanCurr)}</td>
        <td>${formatNumber(principal)}</td>
        <td>${formatNumber(interest)}</td>
        <td>${formatNumber(sum)}</td>
      </tr>
    `;
  }

  html += `
    <tr class="table-footer gray-light">
      <td>Tổng</td>
      <td></td>
      <td></td>
      <td>${formatNumber(sumPrincipal)}</td>
      <td>${formatNumber(sumInterest)}</td>
      <td>${formatNumber((sumPrincipal + sumInterest))}</td>
    </tr>
  `;

  return tBody.innerHTML = html;
}

// ~ Add event button
btnCalc.addEventListener('click', (e) => {
  e.preventDefault();

  handleLoan();

  if (loan.value.indexOf(',') !== -1) {
    loan.value = +(loan.value.replace(/,/g, ''));
    handleLoan();
    loan.value = formatNumber(+loan.value);
  } else {
    loan.value = formatNumber(+loan.value);
  }
});