const height = document.getElementById('height');
const weight = document.getElementById('weight');
const btnSubmit = document.getElementById('btn-submit');
const heading = document.getElementById('heading');

function typeBMI(string) {
  const number = parseInt(string);

  if (number < 18.5) {
    type = 'Gầy';
    danger = 'Thấp';
  } else if (number >= 18.5 && number <= 24.9) {
    type = 'Bình thường';
    danger = 'Trung bình';
  } else if (number >= 25.0 && number <= 29.9) {
    type = 'Hơi béo';
    danger = 'Cao';
  } else if (number >= 30.0 && number <= 34.9) {
    type = 'Béo phì cấp 1';
    danger = 'Cao';
  } else if (number >= 35.0 && number <= 39.9) {
    type = 'Béo phì cấp 2';
    danger = 'Rất cao';
  } else if (number >= 40.0) {
    type = 'Béo phì cấp 3';
    danger = 'Nguy hiểm';
  }

  return `- Phân loại: ${type} - Mức độ nguy hiểm: ${danger}`;
}

typeBMI(calculatorBMI());

function calculatorBMI() {
  const result = (weight.value / (Math.pow((height.value / 100), 2))).toFixed(2);

  return result;
}

btnSubmit.addEventListener('click', (e) => {
  e.preventDefault();

  heading.innerHTML = `${calculatorBMI()} ${typeBMI()}`;
  height.value = '';
  weight.value = '';
  height.focus();
});